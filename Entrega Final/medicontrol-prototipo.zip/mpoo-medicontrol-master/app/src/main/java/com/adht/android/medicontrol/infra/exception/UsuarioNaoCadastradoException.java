package com.adht.android.medicontrol.infra.exception;

public class UsuarioNaoCadastradoException extends Exception {
    public UsuarioNaoCadastradoException(String usuário_não_cadastrado) {
    }
}
