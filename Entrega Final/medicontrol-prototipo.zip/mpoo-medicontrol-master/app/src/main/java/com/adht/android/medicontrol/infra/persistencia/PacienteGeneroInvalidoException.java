package com.adht.android.medicontrol.infra.persistencia;

public class PacienteGeneroInvalidoException extends Exception {
    public PacienteGeneroInvalidoException(String genero_inválido) {
    }
}
