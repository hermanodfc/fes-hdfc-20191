package com.adht.android.medicontrol.infra.exception;

public class UsuarioEmailInvalidoException extends Exception {
    public UsuarioEmailInvalidoException(String endereço_de_email_inválido) {
    }
}
