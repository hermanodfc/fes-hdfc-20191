package com.adht.android.medicontrol.infra.exception;

public class PacienteInvalidoException extends Exception {
    public PacienteInvalidoException(String paciente_inválido) {
    }
}
