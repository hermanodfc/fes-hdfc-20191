package com.adht.android.medicontrol.infra.persistencia;

public class AmizadeSemAmigos extends Exception {
    public AmizadeSemAmigos(String mensagem) {
    }
}
