package com.adht.android.medicontrol.infra.exception;

public class PacienteNascimentoInvalidoException extends Exception {
    public PacienteNascimentoInvalidoException(String data_de_nascimento_inválida) {
    }
}
