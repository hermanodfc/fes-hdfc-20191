package com.adht.android.medicontrol.paciente.dominio;

public enum Genero {
    FEMININO,
    MASCULINO;
}
