package com.adht.android.medicontrol.infra.ui;

public enum TaskResultType {
    SUCCESS, FAIL, CANCEL;
}
