package com.adht.android.medicontrol.infra.exception;

public class MedicamentoNomeInvalidoException extends Exception {
    public MedicamentoNomeInvalidoException(String nome_inválido) {
    }
}
