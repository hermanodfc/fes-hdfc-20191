package com.adht.android.medicontrol.infra.exception;

public class UsuarioJaCadastradoException extends Exception {
    public UsuarioJaCadastradoException(String usuário_já_cadastrado) {
    }
}
