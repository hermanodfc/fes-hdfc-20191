package com.adht.android.medicontrol.infra.exception;

public class AmizadeExistenteException extends Exception {
    public AmizadeExistenteException(String s) {
    }
}
