package com.adht.android.medicontrol.paciente.dominio;

public enum StatusAmizade {
    PENDENTE,
    ACEITO
}
