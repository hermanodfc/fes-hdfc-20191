package com.adht.android.medicontrol.infra.exception;

public class PacienteNomeInvalidoException extends Exception {
    public PacienteNomeInvalidoException(String nome_inválido) {
    }
}
