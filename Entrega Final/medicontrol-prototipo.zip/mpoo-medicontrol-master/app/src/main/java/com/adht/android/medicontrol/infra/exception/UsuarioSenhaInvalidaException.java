package com.adht.android.medicontrol.infra.exception;

public class UsuarioSenhaInvalidaException extends Exception {
    public UsuarioSenhaInvalidaException(String s) {
    }
}
